#ifndef LWIP_HDR_TEST_NETIF_H
#define LWIP_HDR_TEST_NETIF_H

#include "../lwip_check.h"

Suite *netif_suite(void);

#endif
